﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Global Loading Overlay Logic
document.addEventListener("DOMContentLoaded", function () {
    const loadingOverlay = document.getElementById("global-loading-overlay");

    if (!loadingOverlay) return;

    // Show loading on standard link clicks
    document.querySelectorAll("a").forEach(link => {
        link.addEventListener("click", function (e) {
            const href = this.getAttribute("href");
            const target = this.getAttribute("target");

            // Ignore links that don't trigger navigation
            if (href && !href.startsWith("#") && !href.startsWith("javascript:") && !href.startsWith("mailto:") && target !== "_blank") {
                // Ignore if the user is opening in a new tab using keyboard modifiers
                if (!e.ctrlKey && !e.metaKey && !e.shiftKey) {
                    loadingOverlay.classList.add("active");
                }
            }
        });
    });

    // Show loading on form submissions
    document.querySelectorAll("form").forEach(form => {
        form.addEventListener("submit", function () {
            // Only show if the form is actually valid (if HTML5 validation is used)
            if (this.checkValidity()) {
                loadingOverlay.classList.add("active");
            }
        });
    });

    // Hide loading when page is restored from bfcache (back/forward button navigation)
    window.addEventListener("pageshow", function (event) {
        if (event.persisted) {
            loadingOverlay.classList.remove("active");
        }
    });
});
