/**
 * Sistema de Snapshots (Recuperar e Continuar) para Formulários Longos
 * Este script salva os dados preenchidos no formulário a cada 5 segundos ou em digitação
 * permitindo recuperar dados perdidos caso a aba seja fechada acidentalmente.
 */
document.addEventListener('DOMContentLoaded', () => {
    // Procura todos os formulários que possuem o atributo data-snapshot-id
    // ou aplica globalmente para o primeiro formulário grande.
    const forms = document.querySelectorAll('form[method="post"]:not([data-no-snapshot])');

    forms.forEach(form => {
        // Gerar um ID único para este formulário baseado no pathname e no action
        const snapshotId = form.getAttribute('data-snapshot-id') || `snapshot_${window.location.pathname.replace(/\//g, '_')}`;
        const localStorageKey = `andreense_form_${snapshotId}`;

        // Verifica se a backend mandou limpar o snapshot (sucesso no salvamento)
        if (document.body.getAttribute('data-clear-snapshot') === snapshotId) {
            localStorage.removeItem(localStorageKey);
            return;
        }

        // Tentar recuperar
        const savedSnapshot = localStorage.getItem(localStorageKey);
        if (savedSnapshot) {
            try {
                const data = JSON.parse(savedSnapshot);
                // Verifica se tem dados úteis
                if (Object.keys(data).length > 0) {
                    mostrarAlertaRecuperacao(form, data, localStorageKey);
                }
            } catch (e) {
                console.error("Erro ao ler snapshot do form", e);
            }
        }

        // Lógica de Salvamento Automático (Debounce)
        let timeout = null;
        form.addEventListener('input', () => {
            clearTimeout(timeout);
            timeout = setTimeout(() => {
                salvarSnapshot(form, localStorageKey);
            }, 2000); // Salva 2 segundos após parar de digitar
        });
        form.addEventListener('change', () => {
            salvarSnapshot(form, localStorageKey);
        });

        // Limpar no submit, apenas pra não atrapalhar no loading. Mas preferencialmente o Backend limpa validando sucesso.
        form.addEventListener('submit', () => {
            // Opcional: localStorage.removeItem(localStorageKey);
            // Melhor não remover aqui, caso dê erro de validação (ex: ModelState).
        });
    });

    function salvarSnapshot(form, key) {
        const formData = new FormData(form);
        const dataObj = {};
        
        formData.forEach((value, k) => {
            // Ignorar tokens de segurança ou campos de senha
            if (k !== '__RequestVerificationToken' && !k.toLowerCase().includes('senha') && !k.toLowerCase().includes('password')) {
                // Se o campo já existe (ex: checkbox array), transforma em array
                if (dataObj[k] !== undefined) {
                    if (!Array.isArray(dataObj[k])) {
                        dataObj[k] = [dataObj[k]];
                    }
                    dataObj[k].push(value);
                } else {
                    dataObj[k] = value;
                }
            }
        });

        localStorage.setItem(key, JSON.stringify(dataObj));
    }

    function mostrarAlertaRecuperacao(form, data, key) {
        // Criar um alerta bonitinho estilo toast no topo do form, responsivo e moderno
        const alertDiv = document.createElement('div');
        alertDiv.className = 'alert alert-warning d-flex flex-column flex-md-row align-items-start align-items-md-center justify-content-between gap-3 mb-4 shadow-sm p-3';
        alertDiv.style.borderRadius = 'var(--radius-lg)';
        alertDiv.innerHTML = `
            <div class="d-flex align-items-start gap-3">
                <div class="mt-1 flex-shrink-0 text-warning d-flex align-items-center justify-content-center" style="background: rgba(245, 158, 11, 0.15); padding: 8px; border-radius: 8px;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
                </div>
                <div>
                    <strong style="font-weight: 600; color: var(--text-primary, #1e293b); font-size: 0.95rem;">Rascunho Encontrado!</strong><br/>
                    <span class="small" style="color: var(--text-secondary, #64748b);">Parece que você preencheu dados não salvos anteriormente. Deseja recuperá-los?</span>
                </div>
            </div>
            <div class="d-flex gap-2 w-100 w-md-auto justify-content-end align-self-stretch align-self-md-center">
                <button type="button" class="btn btn-sm btn-outline-secondary flex-fill flex-md-initial px-3 py-1.5" id="btn-discard-snapshot" style="font-size: 0.85rem; font-weight: 500; border-radius: 6px;">Descartar</button>
                <button type="button" class="btn btn-sm btn-warning flex-fill flex-md-initial px-3 py-1.5" id="btn-restore-snapshot" style="font-size: 0.85rem; font-weight: 500; border-radius: 6px; background-color: var(--bs-warning, #f59e0b); border-color: var(--bs-warning, #f59e0b); color: #fff;">Recuperar Dados</button>
            </div>
        `;

        form.insertBefore(alertDiv, form.firstChild);

        document.getElementById('btn-discard-snapshot').addEventListener('click', () => {
            localStorage.removeItem(key);
            alertDiv.remove();
        });

        document.getElementById('btn-restore-snapshot').addEventListener('click', () => {
            restaurarDadosFormulario(form, data);
            alertDiv.remove();
        });
    }

    function restaurarDadosFormulario(form, data) {
        Object.keys(data).forEach(key => {
            const inputs = form.querySelectorAll(`[name="${key}"]`);
            if (inputs.length === 0) return;

            const value = data[key];

            inputs.forEach(input => {
                if (input.type === 'radio') {
                    input.checked = (input.value === value);
                } else if (input.type === 'checkbox') {
                    if (Array.isArray(value)) {
                        input.checked = value.includes(input.value);
                    } else {
                        input.checked = (input.value === value || value === 'true' || value === 'on');
                    }
                } else if (input.tagName === 'SELECT') {
                    input.value = value;
                } else {
                    input.value = value;
                }
                
                // Dispara o evento change para o AppInput/HTMX pegar a mudança se precisar
                input.dispatchEvent(new Event('change', { bubbles: true }));
            });
        });
    }
});
