// ModuloMonolitico — Interatividade Auth + Pessoas
// Vanilla JS puro, sem dependências

function initTheme() {
  const toggleBtn = document.getElementById('theme-toggle');
  if (!toggleBtn) return;

  const currentTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', currentTheme);

  toggleBtn.addEventListener('click', () => {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const newTheme = isDark ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
  });
}

// Inicializa o tema imediatamente para evitar "flash"
initTheme();

function initApp(container = document) {
  // ─── Lógica do Overlay de Loading Global ──────────────────
  window.showLoading = function(text = "Carregando...") {
    const overlay = document.getElementById('global-loading-overlay');
    const textEl = document.getElementById('global-loading-text');
    if (overlay) {
      if (textEl) textEl.innerText = text;
      overlay.classList.add('active');
    }
  };

  window.hideLoading = function() {
    const overlay = document.getElementById('global-loading-overlay');
    if (overlay) overlay.classList.remove('active');
  };

  // ─── Botão de submit: previne double-click e mostra loading ───
  container.querySelectorAll('form:not([data-initialized])').forEach(form => {
    form.setAttribute('data-initialized', 'true');
    form.addEventListener('submit', (e) => {
      // Ignora formulários com data-no-loading
      if (form.hasAttribute('data-no-loading')) return;

      const btn = form.querySelector('button[type=submit]');
      if (btn) {
        btn.disabled = true;
        btn.setAttribute('aria-busy', 'true');
      }
      
      // Mostra overlay de loading
      window.showLoading("Processando...");
    });
    // HTMX: reabilita após resposta
    form.addEventListener('htmx:afterRequest', () => {
      window.hideLoading();
      const btn = form.querySelector('button[type=submit]');
      if (btn) {
        btn.disabled = false;
        btn.removeAttribute('aria-busy');
      }
    });
  });

  // ─── Toggle de visibilidade de senha ─────────────────────────
  container.querySelectorAll('[data-toggle-password]:not([data-initialized])').forEach(btn => {
    btn.setAttribute('data-initialized', 'true');
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-toggle-password');
      const input = document.getElementById(targetId);
      if (!input) return;
      const isPass = input.type === 'password';
      input.type = isPass ? 'text' : 'password';
      btn.querySelector('.icon-eye-open')?.classList.toggle('hidden', !isPass);
      btn.querySelector('.icon-eye-closed')?.classList.toggle('hidden', isPass);
    });
  });

  // ─── Indicador de Senha Forte ───────────────────────────────────
  container.querySelectorAll('input[type=password]').forEach(input => {
    const containerStrength = document.getElementById(`strength-container-${input.id}`);
    if (!containerStrength) return;

    // Mostrar os requisitos quando o campo recebe foco
    input.addEventListener('focus', () => {
      containerStrength.style.display = 'block';
    });

    const checkIcon = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#81c995" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
    const circleIcon = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--clr-text-subtle)" stroke-width="3"><circle cx="12" cy="12" r="10"></circle></svg>`;

    const updateRequirement = (reqEl, meetsRequirement) => {
      if (!reqEl) return;
      const iconContainer = reqEl.querySelector('.req-icon');
      if (iconContainer) {
        iconContainer.innerHTML = meetsRequirement ? checkIcon : circleIcon;
      }
      if (meetsRequirement) {
        reqEl.style.color = 'var(--clr-text)';
      } else {
        reqEl.style.color = 'var(--clr-text-muted)';
      }
    };

    input.addEventListener('input', () => {
      const val = input.value;
      
      const meetsLength = val.length >= 8;
      const meetsUpper = /[A-Z]/.test(val);
      const meetsLower = /[a-z]/.test(val);
      const meetsNumber = /\d/.test(val);
      const meetsSpecial = /[@$!%*?&]/.test(val);

      updateRequirement(containerStrength.querySelector(`#req-length-${input.id}`), meetsLength);
      updateRequirement(containerStrength.querySelector(`#req-upper-${input.id}`), meetsUpper);
      updateRequirement(containerStrength.querySelector(`#req-lower-${input.id}`), meetsLower);
      updateRequirement(containerStrength.querySelector(`#req-number-${input.id}`), meetsNumber);
      updateRequirement(containerStrength.querySelector(`#req-special-${input.id}`), meetsSpecial);

      // Calcular pontuação (0 a 5)
      let score = 0;
      if (meetsLength) score++;
      if (meetsUpper) score++;
      if (meetsLower) score++;
      if (meetsNumber) score++;
      if (meetsSpecial) score++;

      const progressBar = containerStrength.querySelector(`#strength-bar-${input.id}`);
      const progressText = containerStrength.querySelector(`#strength-text-${input.id}`);

      if (progressBar && progressText) {
        let pct = (score / 5) * 100;
        progressBar.style.width = `${pct}%`;

        if (val.length === 0) {
          progressBar.style.width = '0%';
          progressBar.style.backgroundColor = '#ea4335';
          progressText.innerText = 'Fraca';
          progressText.style.color = '#ea4335';
        } else if (score <= 2) {
          progressBar.style.backgroundColor = '#ea4335'; // vermelho
          progressText.innerText = 'Fraca';
          progressText.style.color = '#ea4335';
        } else if (score <= 4) {
          progressBar.style.backgroundColor = '#fbbc04'; // amarelo/laranja
          progressText.innerText = 'Média';
          progressText.style.color = '#fbbc04';
        } else {
          progressBar.style.backgroundColor = '#81c995'; // verde
          progressText.innerText = 'Forte';
          progressText.style.color = '#81c995';
        }
      }
    });
  });

  // ─── Máscaras ────────────────────────────────────────────────
  const applyMask = (selector, logic) => {
    container.querySelectorAll(selector + ':not([data-initialized])').forEach(input => {
      input.setAttribute('data-initialized', 'true');
      input.addEventListener('input', logic);
    });
  };

  // CPF: 000.000.000-00
  applyMask('[data-mask=cpf]', e => {
    let v = e.target.value.replace(/\D/g, '').slice(0, 11);
    if (v.length > 9) v = v.replace(/(\d{3})(\d{3})(\d{3})(\d{1,2})/, '$1.$2.$3-$4');
    else if (v.length > 6) v = v.replace(/(\d{3})(\d{3})(\d{1,3})/, '$1.$2.$3');
    else if (v.length > 3) v = v.replace(/(\d{3})(\d{1,3})/, '$1.$2');
    e.target.value = v;
  });

  // CNPJ: 00.000.000/0000-00
  applyMask('[data-mask=cnpj]', e => {
    let v = e.target.value.replace(/\D/g, '').slice(0, 14);
    if (v.length > 12) v = v.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{1,2})/, '$1.$2.$3/$4-$5');
    else if (v.length > 8) v = v.replace(/(\d{2})(\d{3})(\d{3})(\d{1,4})/, '$1.$2.$3/$4');
    else if (v.length > 5) v = v.replace(/(\d{2})(\d{3})(\d{1,3})/, '$1.$2.$3');
    else if (v.length > 2) v = v.replace(/(\d{2})(\d{1,3})/, '$1.$2');
    e.target.value = v;
  });

  // Telefone: (00) 00000-0000
  applyMask('[data-mask=telefone]', e => {
    let v = e.target.value.replace(/\D/g, '').slice(0, 11);
    if (v.length > 6) v = v.replace(/(\d{2})(\d{5})(\d{1,4})/, '($1) $2-$3');
    else if (v.length > 2) v = v.replace(/(\d{2})(\d{1,5})/, '($1) $2');
    e.target.value = v;
  });

  // CEP: 00000-000
  applyMask('[data-mask=cep]', e => {
    let v = e.target.value.replace(/\D/g, '').slice(0, 8);
    if (v.length > 5) v = v.replace(/(\d{5})(\d{1,3})/, '$1-$2');
    e.target.value = v;
  });

  // ─── Busca de Endereço por CEP ───────────────────────────────
  container.querySelectorAll('[data-mask=cep]:not([data-cep-bound])').forEach(input => {
    input.setAttribute('data-cep-bound', 'true');
    input.addEventListener('focusout', async (e) => {
      const cepStr = e.target.value.replace(/\D/g, '');
      if (cepStr.length !== 8) return;

      // Detecta se o ID usa _ (Razor) ou - (Manual)
      const separator = input.id.includes('_') ? '_' : '-';
      const parts = input.id.split(separator);
      const prefix = parts.slice(0, parts.length - 1).join(separator);

      const getEl = (suffix) => {
        // Tenta PascalCase (Razor) e lowercase
        return document.getElementById(`${prefix}${separator}${suffix.charAt(0).toUpperCase() + suffix.slice(1)}`) || 
               document.getElementById(`${prefix}${separator}${suffix.toLowerCase()}`);
      };

      const elLogradouro = getEl('logradouro');
      const elBairro     = getEl('bairro');
      const elCidade     = getEl('cidade');
      const elUf         = getEl('uf');
      const elNumero     = getEl('numero');

      if (!elLogradouro && !elBairro && !elCidade) return;

      // Efeito visual de carregamento
      input.classList.add('loading-cep');
      const originalIcon = input.style.backgroundImage;
      input.style.opacity = '0.7';
      input.style.cursor = 'wait';

      try {
        const response = await fetch(`/Api/Cep?cep=${cepStr}`);
        const data = await response.json();

        if (data.encontrado) {
          if (elLogradouro) elLogradouro.value = data.logradouro;
          if (elBairro) elBairro.value = data.bairro;
          if (elCidade) elCidade.value = data.cidade;
          if (elUf) elUf.value = data.uf;
          
          if (elNumero) elNumero.focus();
        }
      } catch (err) {
        console.error('Erro ao buscar CEP:', err);
      } finally {
        input.classList.remove('loading-cep');
        input.style.opacity = '1';
        input.style.cursor = 'default';
      }
    });
  });

  // ─── Papéis: exibir campos extras ao selecionar ───────────────
  container.querySelectorAll('.papel-toggle:not([data-initialized])').forEach(toggle => {
    toggle.setAttribute('data-initialized', 'true');
    const updateExtras = () => {
      const card = toggle.closest('.papel-card');
      const extra = card?.querySelector('.papel-extra');
      if (!extra) return;
      extra.style.display = toggle.checked ? 'block' : 'none';
    };
    toggle.addEventListener('change', updateExtras);
    updateExtras(); // estado inicial
  });
}

// ─── Componente Premium de Notificação Toast ───────────────────
window.showToast = function(message, type = 'success') {
  let container = document.getElementById('app-toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'app-toast-container';
    container.style.cssText = 'position: fixed; top: 2rem; right: 2rem; z-index: 10000; display: flex; flex-direction: column; gap: 0.75rem; pointer-events: none; max-width: 360px; width: calc(100% - 4rem);';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `app-toast app-toast-${type}`;
  toast.style.cssText = 'pointer-events: auto; display: flex; align-items: center; gap: 0.75rem; padding: 1rem 1.25rem; background: var(--glass-bg); border: 1px solid var(--glass-border); border-radius: var(--radius-md); box-shadow: var(--glass-shadow-lg); backdrop-filter: blur(20px); transform: translateX(120%); opacity: 0; transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1), opacity 0.3s ease;';

  // Customização visual por tipo de mensagem
  let iconSvg = '';
  if (type === 'success') {
    iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#81c995" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`;
    toast.style.borderLeft = '4px solid #81c995';
  } else if (type === 'error') {
    iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#f28b82" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>`;
    toast.style.borderLeft = '4px solid #f28b82';
  } else {
    iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--clr-primary)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`;
    toast.style.borderLeft = '4px solid var(--clr-primary)';
  }

  toast.innerHTML = `
    <div style="display:flex; align-items:center; justify-content:center; flex-shrink:0;">${iconSvg}</div>
    <div style="flex-grow:1; font-family:var(--font-body); font-size:0.875rem; font-weight:500; color:var(--clr-text); line-height:1.4;">${message}</div>
    <button type="button" style="background:none; border:none; color:var(--clr-text-subtle); cursor:pointer; display:flex; align-items:center; justify-content:center; padding:0.2rem; margin-left:0.5rem; transition:color 0.2s;" onclick="this.parentElement.style.transform='translateX(120%)'; this.parentElement.style.opacity='0'; setTimeout(()=>this.parentElement.remove(), 300)">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
    </button>
  `;

  container.appendChild(toast);

  // Animação de Entrada suave
  setTimeout(() => {
    toast.style.transform = 'translateX(0)';
    toast.style.opacity = '1';
  }, 50);

  // Auto-dismiss após 4 segundos
  setTimeout(() => {
    if (toast.parentElement) {
      toast.style.transform = 'translateX(120%)';
      toast.style.opacity = '0';
      setTimeout(() => {
        if (toast.parentElement) toast.remove();
      }, 300);
    }
  }, 4000);
};

// ─── Componente Premium de Mensagem em Modal (showModal) ───────
window.showModal = function(title, message, type = 'success', onConfirm = null) {
  const validTypes = ['success', 'error', 'info'];

  // Caso 1: Chamada simplificada com 2 argumentos onde o segundo é o tipo
  // Ex: showModal("E-mail validado...", "success")
  if (typeof message === 'string' && validTypes.includes(message.toLowerCase()) && (typeof type === 'undefined' || type === 'success' || typeof type === 'function')) {
    if (typeof type === 'function') {
      onConfirm = type;
    }
    type = message.toLowerCase();
    message = title;
    title = type === 'error' ? 'Erro' : (type === 'success' ? 'Sucesso' : 'Aviso');
  }
  // Caso 2: Chamada simplificada com apenas 1 argumento (o título vira a mensagem)
  else if (typeof message === 'undefined' || message === null) {
    message = title;
    title = type === 'error' ? 'Erro' : (type === 'success' ? 'Sucesso' : 'Aviso');
  }

  // Remove qualquer modal dinâmico anterior para evitar empilhamento indesejado
  const modalAnterior = document.getElementById('app-dynamic-modal-overlay');
  if (modalAnterior) {
    modalAnterior.remove();
  }

  // Define cores e ícones baseados no tipo
  let iconSvg = '';
  let colorAccent = 'var(--clr-primary, #8ab4f8)';
  
  if (type === 'success') {
    iconSvg = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#81c995" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`;
    colorAccent = '#81c995';
  } else if (type === 'error') {
    iconSvg = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f28b82" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>`;
    colorAccent = '#f28b82';
  } else {
    iconSvg = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--clr-primary)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`;
    colorAccent = 'var(--clr-primary)';
  }

  // Cria o overlay do modal
  const overlay = document.createElement('div');
  overlay.id = 'app-dynamic-modal-overlay';
  overlay.style.cssText = 'position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.55); backdrop-filter: blur(12px); z-index: 11000; display: flex; align-items: center; justify-content: center; padding: 1.5rem; opacity: 0; transition: opacity 0.25s ease;';

  // Cria o card do modal com visual Glassmorphic Premium
  const card = document.createElement('div');
  card.style.cssText = 'width: 100%; max-width: 480px; background: var(--glass-bg, rgba(30, 30, 30, 0.75)); backdrop-filter: blur(25px); border: 1px solid var(--glass-border, rgba(255, 255, 255, 0.1)); border-radius: var(--radius-lg, 12px); box-shadow: var(--glass-shadow-lg, 0 8px 32px 0 rgba(0, 0, 0, 0.3)); overflow: hidden; transform: scale(0.9); opacity: 0; transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1), opacity 0.3s ease;';

  // Conteúdo HTML interno do card
  card.innerHTML = `
    <div style="display: flex; align-items: center; gap: 0.75rem; padding: 1.25rem 1.75rem; border-bottom: 1px solid var(--glass-border, rgba(255, 255, 255, 0.1));">
      <div style="display: flex; align-items: center; justify-content: center; flex-shrink: 0;">${iconSvg}</div>
      <span style="font-family: var(--font-heading, inherit); font-size: 1.1rem; font-weight: 600; color: var(--clr-text, #ffffff);">${title}</span>
    </div>
    <div style="padding: 1.75rem; font-family: var(--font-body, inherit); font-size: 0.9375rem; color: var(--clr-text-muted, #cccccc); line-height: 1.5; border-bottom: 1px solid var(--glass-border, rgba(255, 255, 255, 0.1));">
      ${message}
    </div>
    <div style="display: flex; justify-content: flex-end; padding: 1rem 1.75rem; background: rgba(0,0,0,0.15);">
      <button id="app-dynamic-modal-confirm" type="button" style="background: ${colorAccent}; border: none; border-radius: var(--radius-sm, 4px); color: #121212; padding: 0.5rem 1.75rem; font-family: var(--font-heading, inherit); font-size: 0.875rem; font-weight: 600; cursor: pointer; transition: opacity 0.2s; outline: none; box-shadow: 0 2px 8px rgba(0,0,0,0.2);">
        Ok
      </button>
    </div>
  `;

  overlay.appendChild(card);
  document.body.appendChild(overlay);

  // Função para fechar o modal com animação de saída suave
  const closeModal = () => {
    overlay.style.opacity = '0';
    card.style.transform = 'scale(0.9)';
    card.style.opacity = '0';
    setTimeout(() => {
      overlay.remove();
      if (typeof onConfirm === 'function') {
        onConfirm();
      }
    }, 250);
  };

  // Evento de clique no botão OK
  card.querySelector('#app-dynamic-modal-confirm').addEventListener('click', closeModal);

  // Evento de clique no overlay (fundo borrado) para fechar opcionalmente
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) {
      closeModal();
    }
  });

  // Fechamento inteligente ao pressionar a tecla ESC
  const keyHandler = (e) => {
    if (e.key === 'Escape') {
      document.removeEventListener('keydown', keyHandler);
      closeModal();
    }
  };
  document.addEventListener('keydown', keyHandler);

  // Ativa a transição suave de entrada
  setTimeout(() => {
    overlay.style.opacity = '1';
    card.style.transform = 'scale(1)';
    card.style.opacity = '1';
  }, 20);
};

document.addEventListener('DOMContentLoaded', () => initApp(document));
document.addEventListener('htmx:load', (e) => initApp(e.detail.elt));
